export function shareTypes(): string {
  return 'share-types';
}
