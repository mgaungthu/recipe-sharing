export class Recipe {}
